# apps/weerstation_app.py

def fahrenheit(c):
    return 32 + 1.8 * c

def gevoelstemperatuur(c, wind, vocht):
    return c - (vocht / 100) * wind

def weerrapport(c, wind, vocht):
    g = gevoelstemperatuur(c, wind, vocht)
    if g < 0 and wind > 10:
        return "Het is heel koud en het stormt! Verwarming aan!"
    elif g < 0 and wind <= 10:
        return "Het is behoorlijk koud! Verwarming aan!"
    elif 0 <= g < 10 and wind > 12:
        return "Het is best koud en het waait; verwarming aan en roosters dicht!"
    elif 0 <= g < 10 and wind <= 12:
        return "Het is een beetje koud, de kachel mag aan!"
    elif 10 <= g < 22:
        return "Heerlijk weer, niet te koud of te warm."
    else:
        return "Warm! Airco aan!"

def _lees_float(prompt):
    while True:
        s = input(prompt).strip()
        if s == "":
            return None
        try:
            return float(s)
        except ValueError:
            print("Ongeldige invoer. Voer een getal in of druk Enter om te stoppen.")

def _lees_int(prompt, min_incl, max_incl):
    while True:
        s = input(prompt).strip()
        if s == "":
            return None
        try:
            v = int(s)
        except ValueError:
            print(f"Ongeldige invoer. Voer een geheel getal {min_incl}..{max_incl} in of Enter om te stoppen.")
            continue
        if min_incl <= v <= max_incl:
            return v
        print(f"Buiten bereik. Kies {min_incl}..{max_incl} of Enter om te stoppen.")

def run_weerstation():
    print("=== WEERSTATION ===")
    temps = []
    for dag in range(1, 8):
        t = _lees_float(f"Dag {dag} temperatuur [°C] (Enter = stop): ")
        if t is None: break
        w = _lees_float(f"Dag {dag} windsnelheid [m/s] (Enter = stop): ")
        if w is None: break
        v = _lees_int(f"Dag {dag} luchtvochtigheid [% 0..100] (Enter = stop): ", 0, 100)
        if v is None: break

        temps.append(t)
        temp_f = fahrenheit(t)
        rapport = weerrapport(t, w, v)
        gem = sum(temps)/len(temps)

        print(f"Het is {t:.1f}°C ({temp_f:.1f}°F)")
        print(rapport)
        print(f"Gem. temp tot nu toe is {gem:.1f}°C")
        print("-" * 40)
