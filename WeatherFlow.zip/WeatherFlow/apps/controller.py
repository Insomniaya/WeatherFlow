# apps/controller.py

def _lees_input_bestand(input_file):
    records = []
    with open(input_file, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f.readlines()]
    if not lines:
        return records
    for line in lines[1:]:
        if not line:
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        date = parts[0]
        num_people = int(parts[1])
        temp_set = float(parts[2])
        temp_out = float(parts[3])
        precip = float(parts[4])
        records.append({
            "date": date,
            "numPeople": num_people,
            "tempSetpoint": temp_set,
            "tempOutside": temp_out,
            "precip": precip,
        })
    return records

def _schrijf_output_bestand(output_file, rows):
    with open(output_file, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(f"{r['date']};{r['cv']};{r['vent']};{str(r['water'])}\n")

def _lees_output_bestand(output_file):
    rows = []
    with open(output_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(";")
            if len(parts) != 4:
                continue
            date, cv_s, vent_s, water_s = parts
            rows.append({
                "date": date,
                "cv": int(cv_s),
                "vent": int(vent_s),
                "water": True if water_s == "True" else False
            })
    return rows

def aantal_dagen(inputFile):
    records = _lees_input_bestand(inputFile)
    return len(records)

def auto_bereken(inputFile, outputFile):
    records = _lees_input_bestand(inputFile)
    rows = []
    for rec in records:
        diff = rec["tempSetpoint"] - rec["tempOutside"]
        if diff >= 20:
            cv = 100
        elif diff >= 10:
            cv = 50
        else:
            cv = 0
        vent = rec["numPeople"] + 1
        if vent > 4:
            vent = 4
        water = rec["precip"] < 3
        rows.append({"date": rec["date"], "cv": cv, "vent": vent, "water": water})
    _schrijf_output_bestand(outputFile, rows)
    print(f"Autoberekening afgerond. Gegevens zijn opgeslagen in {outputFile}")

def overwrite_settings(outputFile):
    try:
        rows = _lees_output_bestand(outputFile)
    except FileNotFoundError:
        print("Het outputbestand bestaat nog niet. Kies eerst optie 2 (autoberekenen).")
        return -3
    if not rows:
        print("Het outputbestand is leeg. Kies eerst optie 2 (autoberekenen).")
        return -3

    datum = input("Datum (bijv. 08-10-2024): ").strip()
    systeem = input("Systeem (1=CV, 2=Ventilatie, 3=Bewatering): ").strip()
    waarde = input("Nieuwe waarde: ").strip()

    if systeem not in ("1", "2", "3"):
        print("Ongeldig systeem.")
        return -3

    idx = -1
    for i, r in enumerate(rows):
        if r["date"] == datum:
            idx = i
            break
    if idx == -1:
        print("Datum niet gevonden.")
        return -1

    if systeem == "1":
        try:
            v = int(waarde)
        except ValueError:
            print("Ongeldige waarde voor CV (0..100).")
            return -3
        if v < 0 or v > 100:
            print("Ongeldige waarde voor CV (0..100).")
            return -3
        rows[idx]["cv"] = v
    elif systeem == "2":
        try:
            v = int(waarde)
        except ValueError:
            print("Ongeldige waarde voor Ventilatie (0..4).")
            return -3
        if v < 0 or v > 4:
            print("Ongeldige waarde voor Ventilatie (0..4).")
            return -3
        rows[idx]["vent"] = v
    else:
        if waarde not in ("0", "1"):
            print("Ongeldige waarde voor Bewatering (0 of 1).")
            return -3
        rows[idx]["water"] = (waarde == "1")

    _schrijf_output_bestand(outputFile, rows)
    print("Waarde succesvol aangepast.")
    return 0

def controller_menu(input_file, output_file):
    while True:
        print("\nSMART APP CONTROLLER")
        print("1) Aantal dagen weergeven")
        print("2) Autobereken en schrijf naar output")
        print("3) Overschrijf een waarde in output")
        print("4) Terug")
        keuze = input("Maak een keuze (1-4): ").strip()
        if keuze == "1":
            try:
                n = aantal_dagen(input_file)
                print(f"Aantal dagen in inputbestand: {n}")
            except FileNotFoundError:
                print("Inputbestand niet gevonden.")
        elif keuze == "2":
            try:
                auto_bereken(input_file, output_file)
            except FileNotFoundError:
                print("Inputbestand niet gevonden.")
        elif keuze == "3":
            overwrite_settings(output_file)
        elif keuze == "4":
            break
        else:
            print("Ongeldige keuze. Kies 1-4.")
