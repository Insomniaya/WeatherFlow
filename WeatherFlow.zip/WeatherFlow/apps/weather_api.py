# apps/weather_api.py
import json
from urllib.request import urlopen
from urllib.error import URLError

UTRECHT_LAT = 52.0908
UTRECHT_LON = 5.1222

def current_temp(lat, lon):
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}"
        "&current=temperature_2m"
        "&timezone=auto"
    )
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.load(resp)
    except URLError:
        return None, "Netwerkfout of API niet bereikbaar."
    except Exception as ex:
        return None, f"Onverwachte fout: {ex}"

    try:
        temp = data["current"]["temperature_2m"]
        return float(temp), None
    except Exception:
        return None, "Kon huidige temperatuur niet uit het antwoord lezen."




def current_temp_utrecht():
    return current_temp(UTRECHT_LAT, UTRECHT_LON)
