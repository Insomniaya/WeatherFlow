# platform.py
from apps.weerstation_app import run_weerstation
from apps.controller import controller_menu
from apps.weather_api import current_temp_utrecht

def lees_pad(prompt, default):
    p = input(f"{prompt} [{default}]: ").strip()
    return p if p else default

def main():
    print("=== SMART APP PLATFORM ===")
    input_file = "data/input.txt"
    output_file = "data/output.txt"

    while True:
        print("\nHoofdmenu:")
        print("1) Weerstation")
        print("2) Smart App Controller")
        print("3) Huidige temperatuur Utrecht (API)")
        print("4) Stoppen")
        keuze = input("Kies (1-4): ").strip()

        if keuze == "1":
            run_weerstation()

        elif keuze == "2":
            input_file = lees_pad("Inputbestand", input_file)
            output_file = lees_pad("Outputbestand", output_file)
            controller_menu(input_file, output_file)

        elif keuze == "3":
            temp, err = current_temp_utrecht()
            if err:
                print(f"Kon temperatuur niet ophalen: {err}")
            else:
                print(f"Huidige temperatuur Utrecht: {temp:.1f} °C")

        elif keuze == "4":
            print("Programma afgesloten.")
            break

        else:
            print("Ongeldige keuze. Kies 1-4.")

if __name__ == "__main__":
    main()
